#! /usr/bin/python3
import sys
sys.version_info[0]

lab_exercise = "Format"
lab_type = "lab-code"
python_version = ("%s.%s.%s" % (sys.version_info[0], sys.version_info[1], sys.version_info[2]))
print("Exercise: %s" % (lab_exercise))
print("Type: %s" % (lab_type))
print("Python: %s\n" % (python_version))

#====================================

data = "cloudacademy.PYTHON.2019"
data_spaces = "     DevOps"
letter1 = 'a'
word1 = 'cloud'
num1 = '2019'

#CODE1: Strip format string

#CODE2: Lower and upper case string

#CODE3: Swap case string

#CODE4: Title case string

#CODE5: Center string

#CODE6: Left and Right adjust string
